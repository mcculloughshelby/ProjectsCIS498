// Register Page for Movie Buff Forum
// Colorful and Movie-Themed Design with Validation

import React, { useState } from 'react';

const Register = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [id, setId] = useState('');
  const [email, setEmail] = useState('');
  const [city, setCity] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validation Rules
    if (!/^[A-Za-z]+$/.test(firstName)) {
      alert('First Name must not contain numbers.');
      return;
    }
    if (!/^[A-Za-z]+$/.test(lastName)) {
      alert('Last Name must not contain numbers.');
      return;
    }
    if (!/^[0-9]+$/.test(id)) {
      alert('ID must be numeric only.');
      return;
    }
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
      alert('Invalid Email format.');
      return;
    }
    if (!/^[0-9]+$/.test(zipCode)) {
      alert('Zip Code must be numeric only.');
      return;
    }
    if (/\s/.test(username) || /^[0-9!@#$%^&*]/.test(username)) {
      alert('Username must not contain spaces or start with a number/special character.');
      return;
    }
    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{10,}/.test(password)) {
      alert('Password must be at least 10 characters long and contain uppercase, lowercase, and a digit.');
      return;
    }
    alert('Registration Successful!');
  };

  return (
    <div className="pt-20 pb-10 bg-gray-900 text-white min-h-screen">
      <div className="max-w-lg mx-auto bg-gray-800 p-8 rounded-lg shadow-lg">
        <h2 className="text-3xl font-bold text-center mb-6 text-red-600">Register</h2>
        <form onSubmit={handleSubmit}>
          <input type="text" placeholder="First Name" value={firstName} onChange={(e) => setFirstName(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <input type="text" placeholder="Last Name" value={lastName} onChange={(e) => setLastName(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <input type="text" placeholder="ID" value={id} onChange={(e) => setId(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <input type="email" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <select value={city} onChange={(e) => setCity(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400">
            <option value="">Select City</option>
            <option value="New York">New York</option>
            <option value="Los Angeles">Los Angeles</option>
            <option value="Chicago">Chicago</option>
          </select>
          <input type="text" placeholder="Zip Code" value={zipCode} onChange={(e) => setZipCode(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} className="w-full mb-4 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full mb-6 p-2 rounded border-2 border-yellow-600 bg-gray-700 text-white focus:outline-none focus:ring-2 focus:ring-yellow-400" />
          <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded-md transition duration-300">Register</button>
        </form>
      </div>
    </div>
  );
};

export default Register;


