// Home Page for Movie Buff Forum
// Includes a hero section, featured movies, and a call-to-action for joining the community.

import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => {
  return (
    <div className="bg-gray-900 text-white min-h-screen">
      <header className="bg-gray-800 py-4 shadow-md">
        <div className="max-w-7xl mx-auto flex justify-between items-center px-4">
          <h1 className="text-3xl font-bold text-yellow-500">Movie Buff Forum</h1>
          <nav className="space-x-4">
            <Link to="/login" className="hover:text-yellow-400">Login</Link>
            <Link to="/register" className="hover:text-yellow-400">Register</Link>
          </nav>
        </div>
      </header>

      <main className="px-4 py-10 text-center">
        <h2 className="text-4xl md:text-6xl font-bold mb-6">Dive into the World of Movies</h2>
        <p className="text-lg md:text-2xl mb-8">Join a community of movie enthusiasts, share reviews, and discuss your favorite films.</p>
        <Link to="/register" className="bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-8 rounded-full transition duration-300">Join Now</Link>
      </main>

      <section className="px-4 py-10 bg-gray-800">
        <h3 className="text-3xl font-bold mb-6 text-center">Featured Movies</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gray-700 rounded-lg shadow-lg overflow-hidden">
            <img src="/Posters/the fast and the furious.jpeg" alt="The Fast and the Furious" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h4 className="text-xl font-bold">The Fast and the Furious</h4>
              <p className="text-gray-300">The Fast and the Furious (2001): Undercover LAPD officer Brian O'Conner infiltrates the Los Angeles street racing scene to investigate a series of hijackings, leading him to form a complicated relationship with racer Dominic Toretto.</p>
            </div>
          </div>
          <div className="bg-gray-700 rounded-lg shadow-lg overflow-hidden">
            <img src="/Posters/Top Gun.jpeg" alt="Top Gun" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h4 className="text-xl font-bold">Top Gun</h4>
              <p className="text-gray-300">Top Gun (1986): Maverick, a talented but reckless U.S. Navy pilot, competes at the elite Fighter Weapons School, known as "Top Gun," where he confronts personal and professional challenges.</p>
            </div>
          </div>
          <div className="bg-gray-700 rounded-lg shadow-lg overflow-hidden">
            <img src="/Posters/twister.jpeg" alt="Twister" className="w-full h-48 object-cover" />
            <div className="p-4">
              <h4 className="text-xl font-bold">Twister</h4>
              <p className="text-gray-300">Twister (1996): A team of storm chasers, led by Dr. Jo Harding and her estranged husband Bill, pursue tornadoes to deploy a groundbreaking weather data-gathering device during a series of severe storms in Oklahoma.</p>
            </div>
          </div>
        </div>
      </section>

      
    </div>
  );
};

export default Home;

