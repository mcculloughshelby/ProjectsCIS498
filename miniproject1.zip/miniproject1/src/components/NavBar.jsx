// Navbar Component with Integrated Login Form in Column Layout
// Follows all requirements and uses red & black movie-themed colors
// Improved readability for login fields

import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (username === '' || password === '') {
      alert('Please fill in both fields.');
      return;
    }
    if (username !== 'admin' || password !== 'password123') {
      alert('Incorrect username or password.');
      return;
    }
    setIsLoggedIn(true);
  };

  return (
    <>
      <nav className="bg-black text-white shadow-md fixed top-0 w-full z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between h-16 items-center">
            <div className="flex-shrink-0 flex items-center mb-2 md:mb-0">
              <Link to="/" className="text-3xl font-bold text-red-600 hover:text-red-400">
                Movie Buff Forum
              </Link>
            </div>
            <div className="flex flex-col md:flex-row md:space-x-4 items-center">
              <Link to="/" className="hover:text-red-400 mb-2 md:mb-0">Home</Link>
              <Link to="/register" className="hover:text-red-400">Register</Link>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-24 pb-10 bg-gray-900 text-white min-h-screen">
        {!isLoggedIn ? (
          <div className="max-w-sm mx-auto bg-gray-800 p-8 rounded-lg shadow-lg">
            <h2 className="text-3xl font-bold text-center mb-6 text-red-600">Login</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-4">
                <label className="block text-gray-300 text-lg">Username:</label>
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 bg-gray-700 text-white text-lg"
                />
              </div>
              <div className="mb-6">
                <label className="block text-gray-300 text-lg">Password:</label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full px-4 py-3 rounded-md focus:outline-none focus:ring-2 focus:ring-red-600 bg-gray-700 text-white text-lg"
                />
              </div>
              <button
                type="submit"
                className="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-md text-lg font-semibold transition duration-300"
              >
                Login
              </button>
            </form>
          </div>
        ) : (
          <div className="text-center text-3xl text-green-500">
            You are logged in!
          </div>
        )}
      </div>
    </>
  );
};

export default Navbar;

